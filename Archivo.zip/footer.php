<?php $base_url = "https://localhost/familias/"; ?>
<footer id="footer" class="container-full">
   <div class="container-full footer-bg-1 padding-top-bottom-footer"></div>
   <div class="container-full footer-bg-2 padding-top-bottom-footer"></div>
   <div class="container-full footer-bg-3 footer-div-copyright">
       <p class="text-white text-center no-margin-top-bottom text-opensans">Todos los derechos reservados &copy; Paniamor 2018</p>
   </div>
    
</footer>